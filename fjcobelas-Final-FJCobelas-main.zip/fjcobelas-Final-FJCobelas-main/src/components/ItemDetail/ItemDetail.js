import { useContext, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { CartContext } from "../../context/CartContext"
import Memo from "../../ejemplos/Memo/Memo"
import ItemCount from "../ItemCount/ItemCount"
import Select from "../Select/Select"

 const options = [
    {value: 'L', text: 'Grande'},
    {value: 'M', text: 'Mediano'},
    {value: 'S', text: 'Chico'}
] 


const ItemDetail = ({id, nombre, desc, img, precio, category, stock}) => {

    const { addItem, isInCart } = useContext(CartContext)

    const navigate = useNavigate()

    const handleNavigate = () => {
        navigate(-1)
    }

    const [cantidad, setCantidad] = useState(0)
    const [color, setColor] = useState('L')


    const agregarAlCarrito = () => {

        const itemToAdd = {
            id,
            nombre,
            precio,
            img,
            color,
            cantidad
        }

        cantidad > 0 && addItem(itemToAdd)
    }

    return (
        <div>
            <h2>{nombre}</h2>
            <img src={img} alt={nombre}/>
            <p>{desc}</p>
            <h4>Precio: ${precio}</h4>
            <small>Stock disponible: {stock}</small>
            { stock === 0 && <p style={{color: 'red', fontWeight: '700'}}>¡Item sin stock!</p> }

            <Select 
                options={options}
                onSelect={setColor}
            />   

            <Memo/>
            
            <>
                {
                    !isInCart(id)
                    ? <ItemCount 
                        max={stock}
                        cantidad={cantidad}
                        setCantidad={setCantidad}
                        onAdd={agregarAlCarrito}
                    />
                    : <Link to="/cart" className="btn btn-success d-block my-3">Terminar mi compra</Link>
                }
            </>
            
            <hr/>
            <button className="btn btn-outline-primary" onClick={handleNavigate}>Volver</button>
            {/* <button className="btn btn-outline-primary" onClick={() => navigate(-1)}>Volver</button> */}
        </div>
    )
}

export default ItemDetail