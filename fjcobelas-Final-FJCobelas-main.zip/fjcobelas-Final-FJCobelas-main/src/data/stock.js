
export const stock = [
    {
        nombre: 'Producto 1',
        id: 1,
        desc: 'Lorem ipsum producto 1',
        precio: 1500,
        img: 'https://via.placeholder.com/150',
        stock: 50,
        category: 'acuarelas'
    },
    {
        nombre: 'Producto 2',
        id: 2,
        desc: 'Lorem ipsum producto 2',
        precio: 2500,
        img: 'https://via.placeholder.com/150',
        stock: 12,
        category: 'acuarelas'
    },
    {
        nombre: 'Producto 3',
        id: 3,
        desc: 'Lorem ipsum producto 3',
        precio: 3500,
        img: 'https://via.placeholder.com/150',
        stock: 5,
        category: 'cursos'
    },
    {
        nombre: 'Producto 4',
        id: 4,
        desc: 'Lorem ipsum producto 4',
        precio: 4500,
        img: 'https://via.placeholder.com/150',
        stock: 50,
        category: 'cursos'
    },
    {
        nombre: 'Producto 5',
        id: 5,
        desc: 'Lorem ipsum producto 5',
        precio: 5500,
        img: 'https://via.placeholder.com/150',
        stock: 8,
        category: 'acuarelas'
    },
    {
        nombre: 'Producto 6',
        id: 6,
        desc: 'Lorem ipsum producto 6',
        precio: 6500,
        img: 'https://via.placeholder.com/150',
        stock: 0,
        category: 'acuarelas'
    },
]