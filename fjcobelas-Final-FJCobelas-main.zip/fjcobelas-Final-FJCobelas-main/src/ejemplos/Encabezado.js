
export const Encabezado = () => {

    return (
        <header>
            <h1>React Coder</h1>

            <nav>
                <a>Link 1</a>
                <a>Link 2</a>
                <a>Link 3</a>
            </nav>
        </header>
    )
}